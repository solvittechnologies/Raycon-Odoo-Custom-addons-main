## Modul eq_ownerp_ui

#### 02.10.2020
#### Version 1.0.31
##### CHG
- Changed index description

#### 07.09.2020
#### Version 1.0.29
##### CHG
- Changed Template-inherit to new "hasClass" CSS request, solving a warning in serverconsole

#### 11.08.2020
#### Version 1.0.28
##### IMP
- Progress-Bars with different states, now have again their proper state-color

#### 21.07.2020
#### Version 1.0.27
##### IMP
- Repair-Icon for Sidebar now with flip-out-text working too.

#### 21.07.2020
#### Version 1.0.26
##### IMP
- Left Sidebar: Now uses developermode for links as well. Repair-icon is now fixed for Sidebar.

#### 06.05.2020
#### Version 1.0.25
##### CHG
- Small Fix for icons with names in sidebar

#### 06.05.2020
#### Version 1.0.24
##### IMP
- Sidebar Names can now be switched on/off by config

#### 05.05.2020
#### Version 1.0.23
##### IMP
- Sidebar now with new Hover-Text; Sidebar will be invisible on smaller displays.

#### 28.04.2020
#### Version 1.0.22
##### CHG
- remove section with links in index.html 

#### 28.04.2020
#### Version 1.0.21
##### CHG
- Visual bugfix for edit-views with dropdowns; New default parameters; Changed description with german images

#### 27.04.2020
#### Version 1.0.20
##### CHG
- Change translation file

#### 22.04.2020
#### Version 1.0.19
##### CHG
- Updating Module Description

#### 22.04.2020
#### Version 1.0.18
##### ADD
- Function to show chatter notification on right side at detail views

#### 21.04.2020
#### Version 1.0.17
##### IMP
- Settings-Sidebar now with new and old icon-switch + Icon for Mass_Mailing

#### 15.04.2020
#### Version 1.0.16
##### CHG
- Sidebar: Standard Visibility is OFF. New Icons now available in sidebar, with Color-definition for app icons.

#### 09.04.2020
#### Version 1.0.15
##### ADD
- Sidebar-Navigation Function and Styles

#### 09.04.2020
#### Version 1.0.14
##### ADD
- Added option to show old or new icons in app menu.
- Added option to show or hide sidebar(not implemented).

#### 08.04.2020
#### Version 1.0.13
##### FIX
- Removed text which is not allowed between branching directives

#### 07.04.2020
#### Version 1.0.12
##### CHG
- Prepare CSS + NavicationTemplate for Icon-Switch to original App Icons

#### 26.03.2020
#### Version 1.0.11
##### ADD
- New icon for "hr_payroll" (Personalabrechnung)

#### 25.03.2020
#### Version 1.0.10
##### IMP/FIX
- "Chatter" (Notes) will be shown on right side when the display is wide enough. Small Fixes for general mobile views.

#### 24.03.2020
#### Version 1.0.9
##### CHG
- Changing Pre-Defined Colors and Reset-Colors

#### 23.03.2020
#### Version 1.0.8
##### ADD/IMP
- 6 new Color Definitions; Small color Fixes; Project-Card Margin fix

#### 11.03.2020
#### Version 1.0.7
##### ADD
- Adding icon for "Lunch" Module; Improving Position and Size for some Icons

#### 09.03.2020
#### Version 1.0.6
##### FIX
- Fixed form view extension name.

#### 09.03.2020
#### Version 1.0.5
##### IMP
- Text-Editor in Backend: Buttonsize-Fixes

#### 06.03.2020
#### Version 1.0.4
##### CHG
- All buttons in the button box are now always  shown.

#### 04.03.2020
#### Version 1.0.3
##### CHG
- Adding 2 new colors; Set new Standard-Colors; Fixing small Bugs; Adding some translation;

#### 03.03.2020
#### Version 1.0.2
##### FIX
- Fixed close of the apps menu on opening a application.
- Close button is not shown at the start.

#### 02.03.2020
#### Version 1.0.1
##### ADD
- Adding the new ownerp backend ui, as duplicate from eq_backend_ui